namespace HealthTourism.Settings
{
    public class AppSettings
    {
        public string secret { get; set; }
    }
}
## Health Tourism

```
npm install
npm start
```

Runs on localhost:3000
